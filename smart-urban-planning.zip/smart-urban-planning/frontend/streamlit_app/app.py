import streamlit as st
import folium
from streamlit_folium import st_folium

st.set_page_config(page_title='Smart Urban Planning', layout='wide')

st.title("🏙 Smart Urban Planning Dashboard")
st.sidebar.header("Filters")

# Sidebar controls
aoi = st.sidebar.text_input("Enter AOI Name:", "Patna, Bihar")
date_range = st.sidebar.date_input("Select Date Range", [])

# Create map
m = folium.Map(location=[25.6, 85.1], zoom_start=11)
folium.Marker([25.6, 85.1], popup="Urban Center").add_to(m)

# Display map
st_folium(m, width=1200, height=600)

st.subheader("Urban Growth Statistics")
col1, col2, col3 = st.columns(3)
col1.metric("Total Built-up Area", "245.3 km²", "+5.4%")
col2.metric("Deforestation Area", "12.8 km²", "-1.2%")
col3.metric("Illegal Constructions", "127 cases", "+8")

st.write("Use the sidebar to change AOI or Date Range for analysis.")
