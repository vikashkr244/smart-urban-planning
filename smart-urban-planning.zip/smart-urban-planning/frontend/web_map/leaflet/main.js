var map = L.map('map').setView([25.6, 85.1], 11);
L.tileLayer('https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png', {
  maxZoom: 19,
  attribution: '&copy; OpenStreetMap contributors'
}).addTo(map);
L.circle([25.61, 85.13], {color: 'red', radius: 1500}).addTo(map).bindPopup('Detected Urban Growth Area');
