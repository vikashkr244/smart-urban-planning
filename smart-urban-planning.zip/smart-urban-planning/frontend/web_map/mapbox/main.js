mapboxgl.accessToken = 'YOUR_MAPBOX_TOKEN_HERE';
const map = new mapboxgl.Map({
  container: 'map',
  style: 'mapbox://styles/mapbox/satellite-streets-v12',
  center: [85.1, 25.6],
  zoom: 11
});
map.on('load', () => {
  map.addSource('urban-growth', {
    'type': 'geojson',
    'data': 'https://example.com/urban_growth.geojson'
  });
  map.addLayer({
    'id': 'growth',
    'type': 'fill',
    'source': 'urban-growth',
    'paint': { 'fill-color': '#FF0000', 'fill-opacity': 0.4 }
  });
});
