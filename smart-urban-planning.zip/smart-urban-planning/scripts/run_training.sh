#!/bin/bash
echo "🚀 Starting model training..."

source venv/bin/activate 2>/dev/null || echo "No virtual environment found"
python src/models/train.py --config src/config/default.yaml

echo "✅ Training finished. Checkpoints saved in models/checkpoints/"
