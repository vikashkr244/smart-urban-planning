#!/bin/bash
echo "🚀 Running inference pipeline..."

source venv/bin/activate 2>/dev/null || echo "No virtual environment found"
python src/inference/batch_infer.py --input data/intermediate/composites --output data/results/

echo "✅ Inference completed. Results stored in data/results/"
