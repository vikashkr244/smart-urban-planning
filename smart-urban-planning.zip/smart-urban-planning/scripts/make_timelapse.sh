#!/bin/bash
echo "🎞 Generating time-lapse video..."

source venv/bin/activate 2>/dev/null || echo "No virtual environment found"
python src/visualization/timelapse.py --input data/intermediate/composites --output outputs/urban_growth_timelapse.mp4

echo "✅ Time-lapse video saved to outputs/urban_growth_timelapse.mp4"
