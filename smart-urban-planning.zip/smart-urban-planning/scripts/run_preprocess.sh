#!/bin/bash
echo "🚀 Starting preprocessing pipeline..."

source venv/bin/activate 2>/dev/null || echo "No virtual environment found"
python src/preprocessing/preprocess.py

echo "✅ Preprocessing completed successfully."
