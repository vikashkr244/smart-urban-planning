# Metadata Folder
Contains dataset manifest and summary files.