# Cloud Masks
Binary or probability cloud masks.