# Processed Composites
Information on composite creation and naming.