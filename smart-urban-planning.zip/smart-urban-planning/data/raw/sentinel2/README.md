# Sentinel-2 Raw Data
Details on Sentinel-2 data sources and structure.