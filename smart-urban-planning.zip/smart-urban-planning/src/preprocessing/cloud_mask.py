def apply_cloud_mask(image_path):
    print(f"Applying cloud mask on {image_path}")
