def run_preprocessing():
    print("Running preprocessing pipeline...")
