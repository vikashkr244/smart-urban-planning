def coregister_images(base, target):
    print(f"Co-registering {target} to {base}")
