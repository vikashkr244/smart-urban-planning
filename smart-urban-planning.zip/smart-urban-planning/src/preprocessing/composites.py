def create_composite(image_list, out_path):
    print(f"Creating composite at {out_path}")
