def compute_ndvi(nir, red):
    return (nir - red) / (nir + red + 1e-6)
