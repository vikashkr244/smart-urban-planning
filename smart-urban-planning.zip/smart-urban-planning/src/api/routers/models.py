from fastapi import APIRouter
router = APIRouter(prefix='/models', tags=['Models'])
@router.get('/predict')
def predict():
    return {'message': 'Model prediction endpoint'}
