from fastapi import APIRouter
router = APIRouter(prefix='/maps', tags=['Maps'])
@router.get('/tiles')
def get_tiles():
    return {'message': 'Map tiles endpoint'}
