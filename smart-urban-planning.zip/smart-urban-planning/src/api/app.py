from fastapi import FastAPI
from .routers import maps, models
app = FastAPI(title='Smart Urban Planning API')
app.include_router(maps.router)
app.include_router(models.router)
