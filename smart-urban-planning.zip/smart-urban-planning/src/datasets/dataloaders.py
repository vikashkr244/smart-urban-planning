from torch.utils.data import Dataset
class SatelliteDataset(Dataset):
    def __init__(self, img_paths, mask_paths):
        self.imgs = img_paths
        self.masks = mask_paths
    def __len__(self): return len(self.imgs)
    def __getitem__(self, idx): return self.imgs[idx], self.masks[idx]
