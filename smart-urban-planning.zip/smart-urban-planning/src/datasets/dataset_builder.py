def build_dataset(data_dir):
    print(f"Building dataset from {data_dir}")
