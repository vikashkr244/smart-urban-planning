from .celery_worker import app
@app.task
def run_task(name):
    print(f'Running task: {name}')
