def run_batch_inference(model, data_dir):
    print(f"Running batch inference for {data_dir}")
