def postprocess_mask(mask):
    print("Applying morphological filtering...")
