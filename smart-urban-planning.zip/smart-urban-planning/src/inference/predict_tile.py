def predict_tile(tile_path, model):
    print(f"Running inference on {tile_path}")
