def convert_labels_to_geojson(label_path):
    print(f"Converting labels from {label_path} to GeoJSON")
