def generate_weak_labels(image_path):
    print(f"Generating weak labels for {image_path}")
