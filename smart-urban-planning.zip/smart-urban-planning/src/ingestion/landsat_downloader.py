def download_landsat_data(aoi, start, end):
    print(f"Downloading Landsat data for {aoi} from {start} to {end}...")
