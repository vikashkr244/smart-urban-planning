def download_sentinel_data(aoi, start, end):
    print(f"Downloading Sentinel data for {aoi} from {start} to {end}...")
