import geopandas as gpd
def reproject_to_utm(gdf):
    return gdf.to_crs(epsg=32645)
