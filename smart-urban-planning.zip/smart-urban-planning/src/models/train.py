from .unet import UNet
def train_model():
    print("Training UNet model...")
