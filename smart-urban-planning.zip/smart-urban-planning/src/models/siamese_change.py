import torch.nn as nn
class SiameseChangeNet(nn.Module):
    def __init__(self, base_model):
        super().__init__()
        self.encoder = base_model
        self.classifier = nn.Conv2d(2,1,1)
    def forward(self, img1, img2):
        f1, f2 = self.encoder(img1), self.encoder(img2)
        diff = abs(f2 - f1)
        return self.classifier(diff)
