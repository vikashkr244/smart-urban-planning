import torch.nn as nn
def dice_loss(pred, target):
    smooth = 1.
    num = 2*(pred*target).sum() + smooth
    den = pred.sum() + target.sum() + smooth
    return 1 - num/den
