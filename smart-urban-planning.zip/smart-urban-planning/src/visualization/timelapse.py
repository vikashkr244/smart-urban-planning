def generate_timelapse(image_folder, output_video):
    print(f"Generating timelapse {output_video}")
