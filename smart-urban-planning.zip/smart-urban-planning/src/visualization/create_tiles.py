def create_xyz_tiles(raster_path):
    print(f"Creating map tiles from {raster_path}")
