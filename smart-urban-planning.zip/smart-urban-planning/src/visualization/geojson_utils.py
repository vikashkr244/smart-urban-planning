def simplify_geojson(geojson_path):
    print(f"Simplifying {geojson_path}")
