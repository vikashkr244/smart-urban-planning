def compute_growth_rate(before_area, after_area):
    return (after_area - before_area) / before_area
