def generate_heatmap(changes):
    print("Generating urban growth heatmap")
