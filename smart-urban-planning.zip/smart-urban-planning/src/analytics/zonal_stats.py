def compute_zonal_stats(changes, zones):
    print(f"Computing stats for {len(zones)} zones")
