import pytest
from src.inference.predict_tile import predict_tile

class DummyModel:
    def __call__(self, x): return x

@pytest.mark.integration
def test_inference_pipeline(tmp_path):
    tile_path = tmp_path / "tile.tif"
    with open(tile_path, "w") as f:
        f.write("fake raster data")
    model = DummyModel()
    predict_tile(tile_path, model)
