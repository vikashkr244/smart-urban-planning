import os
from src.preprocessing.preprocess import run_preprocessing

def test_preprocess_function(monkeypatch):
    calls = []
    def fake_print(msg): calls.append(msg)
    monkeypatch.setattr("builtins.print", fake_print)
    run_preprocessing()
    assert "Running preprocessing pipeline" in calls[0]
