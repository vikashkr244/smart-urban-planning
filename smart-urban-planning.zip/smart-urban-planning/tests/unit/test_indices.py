import pytest
import numpy as np
from src.preprocessing.indices import compute_ndvi

def test_ndvi_basic():
    nir = np.array([[0.8, 0.5], [0.7, 0.4]])
    red = np.array([[0.4, 0.2], [0.5, 0.3]])
    result = compute_ndvi(nir, red)
    assert result.shape == (2, 2)
    assert np.all((result >= -1) & (result <= 1))

def test_ndvi_zero_division():
    nir = np.zeros((2, 2))
    red = np.zeros((2, 2))
    result = compute_ndvi(nir, red)
    assert np.all(np.isfinite(result))
