# 🏙 Smart Urban Planning - System Architecture

## Overview
This project integrates **Remote Sensing**, **GIS**, and **Machine Learning** to monitor:
- Illegal construction
- Deforestation
- Urban sprawl

## Components
1. **Data Ingestion**
   - Sentinel-2, Landsat-8 via Copernicus & USGS APIs  
   - Processed into cloud-free composites

2. **Preprocessing**
   - Cloud masking, co-registration, and spectral indices  
   - Managed by `src/preprocessing/`

3. **Model Training**
   - UNet & Siamese networks for change detection  
   - Managed by `src/models/`

4. **Inference**
   - Batch predictions and postprocessing  
   - Managed by `src/inference/`

5. **Visualization**
   - Interactive dashboard (Streamlit)  
   - Web map (Leaflet + Mapbox)

## Data Flow
```
Sentinel/Landsat → Preprocessing → Model Training → Inference → Heatmap → Streamlit Dashboard
```

## Tech Stack
- **Python** (FastAPI, Torch, GeoPandas, Rasterio)
- **Streamlit / Leaflet / Mapbox**
- **Docker / Kubernetes / Terraform**
- **CI/CD** via GitHub Actions
