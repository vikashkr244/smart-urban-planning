# 🧹 Labeling & Quality Control Playbook

## Goal
Ensure high-quality labels for change detection training.

## Workflow
1. Annotate using QGIS / Labelbox
2. Save as GeoJSON (EPSG:4326)
3. Validate topology using `src/utils/geo.py`
4. Upload to `data/labels/train/`

## QC Checklist
- ✅ Polygon boundaries align with features
- ✅ No overlaps between classes
- ✅ Minimum polygon area > 50 m²
- ✅ CRS = EPSG:4326
