# 🗂 Data Dictionary

## Satellite Data
| Dataset | Description | Source | Resolution | Format |
|----------|--------------|----------|-------------|----------|
| Sentinel-2 | Optical imagery (13 bands) | ESA Copernicus | 10m | GeoTIFF |
| Landsat-8 | Optical imagery (11 bands) | USGS | 30m | GeoTIFF |

## Derived Products
| Dataset | Description | Format |
|----------|--------------|----------|
| Cloud Masks | Binary mask of clouds | GeoTIFF |
| Composites | Median composite images | GeoTIFF |
| NDVI/NDBI | Vegetation and Built-up indices | GeoTIFF |

## Labels
| File | Type | Description |
|------|------|-------------|
| sample_labels.geojson | GeoJSON | Polygon labels for urban growth |
| labeling_qc.md | Markdown | Labeling QA instructions |
